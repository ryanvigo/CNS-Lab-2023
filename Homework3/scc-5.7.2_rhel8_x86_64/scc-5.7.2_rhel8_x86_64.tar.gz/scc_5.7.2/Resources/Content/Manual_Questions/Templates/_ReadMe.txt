Files in this directory are programatically created by SCC and may be 
overwritten when content is installed or via command line parameter request.  

Editing files in this directory is not recommended.  To use the autoanswer 
templates save the completed autoanswer files to following directory:

<SCC Install>\Resources\Content\Manual_Questions\Completed_Files

Make sure to leave the filename the same in the format of
<STIG Benchmark ID>_<Version>_Autoanswer.txt, as renaming could cause issues.

ex:  Windows_10_STIG_002.005_Autoanswer.txt